# ShotGurnQuiz
 
